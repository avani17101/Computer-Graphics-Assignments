#include "main.h"
const color_t COLOR_RED = { 255, 0, 0 };
const color_t COLOR_GREEN = {0, 255, 0 };
const color_t COLOR_MAGENTA = {255,20,147};
const color_t COLOR_LIGHT_BLUE = {0,191,255};
const color_t COLOR_ORANGERED = {255,69,0};
const color_t COLOR_METALLIC_GOLD = {212,175,55};
const color_t COLOR_BLACK = { 0, 0, 0 };
const color_t COLOR_GOLDEN_BROWN = {153,101,21};
const color_t COLOR_WOOD = {230,190,138};
const color_t COLOR_OLD_GOLD = {255,215,0};
const color_t COLOR_GREY_RING = {119,136,153};
const color_t COLOR_OLIVE = {107,142,35};
const color_t COLOR_SKIN = {198,134,66};    
const color_t COLOR_WHITE = {255, 255, 255};
const color_t COLOR_BACKGROUND = { 220, 220, 220 };
const color_t COLOR_YELLOW = {255, 255, 0};
const color_t COLOR_MAGNET = {47,79,79};
const color_t COLOR_BLUE = {0, 0, 255};

