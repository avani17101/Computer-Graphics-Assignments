rm -rf build
mkdir build
cd build
cmake ..
make
cp Hello-World ../src
