cd build
cmake ..
make
cp Hello-World ../src

